from django.apps import AppConfig


class InteractiveMapConfig(AppConfig):
    name = 'interactive_map'
